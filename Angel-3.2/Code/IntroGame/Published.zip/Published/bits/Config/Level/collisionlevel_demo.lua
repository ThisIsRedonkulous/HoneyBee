Ground = {
  def = "ground_actor",
  position = {0, -11},
  tag = "spawned",
}

Bouncy = {
  def = "physics_event_actor",
  position = {0, 8},
  tag = "spawned",
}
